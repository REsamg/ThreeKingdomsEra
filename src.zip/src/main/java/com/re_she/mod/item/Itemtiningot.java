package com.re_she.mod.item;

import com.re_she.mod.Fmltutor;
import com.re_she.mod.creativetab.CreativeTabsLoader;
import net.minecraft.item.Item;

public class Itemtiningot extends Item
{
    public Itemtiningot()
    {
        super();
        this.setUnlocalizedName(Fmltutor.MODID + "." + "tiningot");
        this.setTextureName(Fmltutor.MODID + ":" + "tiningot");
        this.setCreativeTab(CreativeTabsLoader.re_tabFMLTutor);
    }


}
